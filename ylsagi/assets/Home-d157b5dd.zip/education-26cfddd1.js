import{b as a}from"./bottomInfo-b75a59ea.js";import{l as s}from"./layoutNav-b4a95cfd.js";import{O as c}from"./style-96ccae25.js";import{_ as n,R as r,x as i,o as _,c as m,g as e,a as d,m as p}from"./index-1b3cc193.js";import"./_commonjsHelpers-de833af9.js";const l={class:"page"},u={class:"content"},f=`
# 教育捐助 education 

### 伊莉思AGI (Hong Kong) 将收入的一部分捐助给 Stripe Climate 除碳项目 和 哔哩哔哩公益公益教育

![](https://static.ylsagi.com/img/20240416145341.png)

`,v="preview-only",g={__name:"education",setup(h){const t=r({theme:"vuepress"}),o=i(f);return(x,y)=>(_(),m("div",l,[e(s),d("div",u,[e(p(c),{editorId:v,modelValue:o.value,previewTheme:t.theme},null,8,["modelValue","previewTheme"])]),e(a)]))}},b=n(g,[["__scopeId","data-v-0ce1adaf"]]);export{b as default};
