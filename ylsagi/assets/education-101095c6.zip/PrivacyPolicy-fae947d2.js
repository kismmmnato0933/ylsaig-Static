import{b as s}from"./bottomInfo-09a4fd56.js";import{l as a}from"./layoutNav-33ab8179.js";import{O as c}from"./style-3612b1a1.js";import{_ as r,R as i,x as _,o as l,c as n,g as e,a as m,m as p}from"./index-4fc00eab.js";import"./_commonjsHelpers-de833af9.js";const d={class:"page"},v={class:"content"},u=`
# 隐私条款 Privacy Clause

尊敬的用户：

欢迎访问我们的网站。为了保护您的个人信息和隐私，我们制定了以下隐私条款，详细说明了我们收集、使用和保护您的个人信息的方式。

信息收集：
当您访问我们的网站时，我们可能会收集您的个人信息，包括但不限于电子邮件地址、联系方式等。我们仅会在您自愿提供这些信息的情况下进行收集。

信息使用：
我们收集的个人信息将用于以下目的：

向您提供所需的产品或服务；
处理您的订单或请求；
向您发送有关我们产品或服务的更新和促销信息；
改善我们的网站和服务；
针对您的兴趣和偏好提供个性化的内容和广告。
信息保护：
我们承诺采取合理的安全措施，保护您的个人信息免受未经授权的访问、使用或泄露。我们会采用加密技术、访问控制和其他安全措施来保护您的个人信息。

信息共享：
我们不会将您的个人信息出售、出租或交易给第三方，除非获得您的明确同意或法律要求。我们可能会与合作伙伴共享您的个人信息，以提供更好的产品和服务，但我们会要求他们遵守本隐私条款。

链接到第三方网站：
我们的网站可能包含指向第三方网站的链接。这些第三方网站有自己的隐私政策，我们对其内容和实践不承担任何责任。请在访问这些网站之前仔细阅读其隐私条款。

Cookie和类似技术：
我们可能会使用Cookie和类似技术来收集和存储您的个人信息。这些技术帮助我们提供更好的用户体验和个性化的服务。您可以根据自己的偏好设置浏览器拒绝Cookie，但这可能会影响您使用我们网站的功能。

法律适用：
本隐私条款受适用法律的约束，并应根据该法律进行解释和执行。

隐私权的变更：
我们保留随时修改本隐私条款的权利。任何修改将在我们的网站上发布，并自发布之日起生效。您继续使用我们的网站将被视为接受修改后的隐私条款。

如果您对我们的隐私条款有任何疑问或意见，请随时联系我们。感谢您对我们的信任和支持！

最后更新日期：2023/09/01

https://ylsapp.com/
`,y="preview-only",f={__name:"PrivacyPolicy",setup(h){const o=i({theme:"vuepress"}),t=_(u);return(P,b)=>(l(),n("div",d,[e(a),m("div",v,[e(p(c),{editorId:y,modelValue:t.value,previewTheme:o.theme},null,8,["modelValue","previewTheme"])]),e(s)]))}},w=r(f,[["__scopeId","data-v-0491be3b"]]);export{w as default};
